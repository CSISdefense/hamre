library(testthat)
library(hamre)

test_check("hamre")
